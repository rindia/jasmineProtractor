using Microsoft.Playwright;

namespace TestProject3.Pages;

public class HomePage(IPage page)
{
    private const string ContactLinkText = "#contact-link";

    public async Task ValidateContactText()
    {
        var contactText = await page.Locator(ContactLinkText).InnerTextAsync();
      //  contactText.Should().Be("Contact us", "found some thing else");

    }
}