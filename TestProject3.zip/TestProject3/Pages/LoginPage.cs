using Microsoft.Playwright;

namespace TestProject3.Pages;

public class LoginPage(IPage page)
{
    private const string SigninBtn = ".login";
    private const string TxtEmail = "#email";
    private const string TxtPassword = "#passwd";
    private const string BtnSignIn = "#SubmitLogin";

    public async Task URL() => await page.GotoAsync("http://www.automationpractice.pl/index.php");

    public async Task DoLogin()
    {
        await page.Locator(SigninBtn).ClickAsync();
        await page.Locator(TxtEmail).FillAsync("runable.in@gmail.com");
        await page.Locator(TxtPassword).FillAsync("sainix123");
        await page.Locator(BtnSignIn).ClickAsync();
    }
}