namespace TestProject3.Settings;

public class ConfigurationService
{
    public static void InitializeConfiguration()
    {
    }
}