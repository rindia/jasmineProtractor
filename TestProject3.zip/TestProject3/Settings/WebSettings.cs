namespace TestProject3.Settings;

public class WebSettings
{
    public string BaseUrl { get; set; }
    public int ElementWaitTimeout { get; set; }
    public bool HeadLess { get; set; }
    public int SlowMo { get; set; }
}