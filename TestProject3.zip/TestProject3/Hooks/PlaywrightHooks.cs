using BoDi;
using Microsoft.Playwright;
using TechTalk.SpecFlow;

namespace TestProject3.Hooks;

[Binding]
public class PlaywrightHooks(IObjectContainer objectContainer)
{
    [BeforeScenario]
    public async Task BeforeScenarioAsync()
    {
        var playwright = await Playwright.CreateAsync();
        var browser = await playwright.Firefox.LaunchAsync(new BrowserTypeLaunchOptions
        {
            Headless = false
        });
        var page = await browser.NewPageAsync();
        // await page.GotoAsync("http://www.automationpractice.pl/index.ph");
        objectContainer.RegisterInstanceAs(browser);
        objectContainer.RegisterInstanceAs(page);
    }

    [AfterScenario]
    public async Task AfterScenario()
    {
        var browser = objectContainer.Resolve<IBrowser>();
        await browser.CloseAsync();
    }
}