using Microsoft.Playwright;

namespace TestProject3.Steps;

public abstract class BasePage()
{
    protected IPage _page;
}