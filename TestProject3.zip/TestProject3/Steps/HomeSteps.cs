using Microsoft.Playwright;
using TechTalk.SpecFlow;
using TestProject3.Pages;

namespace TestProject3.Steps;


[Binding]
public class HomeSteps : BasePage
{
    private HomePage _homePage;

    public HomeSteps(IPage page)
    {
        _page = page;
        _homePage = new HomePage(_page);
    }

    [When("User see contact us in home page")]
    public async Task WhenUserSeeContactUsInHomePage()
    {
        Console.WriteLine("");
    }

    [Then("User validate contact us text")]
    public async Task ThenUserValidateContactUsText()
    {
        await _homePage.ValidateContactText();
    }
}