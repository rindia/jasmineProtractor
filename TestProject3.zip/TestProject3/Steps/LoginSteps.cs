using Microsoft.Playwright;
using TechTalk.SpecFlow;
using TestProject3.Pages;

namespace TestProject3.Steps
{
    [Binding]
    public class LoginSteps : BasePage
    {
        private LoginPage _loginPage;

        public LoginSteps(IPage page)
        {
            _page = page;
            _loginPage = new LoginPage(_page);
        }

        [Given(@"User is on login page")]
        public async Task GivenUserIsOnLoginPage()
        {
            _loginPage = new LoginPage(_page);
            await _loginPage.URL();
        }

        [When(@"User submit valid credentials in login form")]
        public async Task WhenUserSubmitValidCredentialsInLoginForm()
        {
            await _loginPage.DoLogin();
        }

        // Add more steps as needed...

        [Then(@"User should redirect to home page")]
        public async Task ThenUserShouldRedirectToHomePage()
        {
            // Add assertion or verification logic for redirection to home page
        }
    }
}